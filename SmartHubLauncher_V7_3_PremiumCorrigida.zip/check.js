
tailwind.config={darkMode:'class',theme:{extend:{colors:{brand:{blue:'#3b82f6',purple:'#8b5cf6',dark:'#0a0c14',card:'#121624',focus:'#60a5fa'}},boxShadow:{'tv-focus':'0 0 0 3px #60a5fa, 0 0 25px rgba(59,130,246,.6)','card-hover':'0 10px 30px -10px rgba(0,0,0,.7)'}}}};
