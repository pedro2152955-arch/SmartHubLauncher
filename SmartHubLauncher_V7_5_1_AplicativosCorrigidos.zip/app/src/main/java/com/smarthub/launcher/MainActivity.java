package com.smarthub.launcher;

import android.app.Activity;
import android.app.AppOpsManager;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("smarthub", MODE_PRIVATE);
        webView = new WebView(this);
        configureWebView();
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.requestFocus();
            webView.evaluateJavascript("window.smartHubRestoreFocus && window.smartHubRestoreFocus();", null);
        }
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new SmartHubBridge(this), "SmartHubAndroid");
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        webView.requestFocus();
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("window.smartHubBack && window.smartHubBack();", null);
        }
    }

    public class SmartHubBridge {
        private final Context context;

        SmartHubBridge(Context context) {
            this.context = context;
        }

        @JavascriptInterface
        public void launchApp(String label) {
            launchApp(label, null);
        }

        @JavascriptInterface
        public void launchApp(String label, String packageName) {
            AppTarget target = null;

            // Quando a tela de Aplicativos fornece o pacote, usamos o pacote
            // diretamente. Isso evita falhas causadas por nomes/labels diferentes.
            if (packageName != null && !packageName.trim().isEmpty()) {
                target = targetFromPackage(packageName.trim());
            }

            // Fallback para atalhos que informam somente o nome do aplicativo.
            if (target == null) {
                target = findApp(label);
            }

            if (target == null) {
                toast("Aplicativo não encontrado: " + label);
                return;
            }

            if (!startTargetActivity(target)) {
                toast("Não foi possível abrir " + target.label);
                return;
            }

            recordLaunch(target.packageName);
        }

        @JavascriptInterface
        public void launchMovie(String title) {
            // Cinema do Smart Hub: prioriza explicitamente o aplicativo instalado
            // "Zapéx Acesso premium do Smart Hub Cinema".
            AppTarget target = findZapexCinemaApp();
            if (target != null) {
                try {
                    Intent launch = new Intent(target.intent);
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    MainActivity.this.startActivity(launch);
                    recordLaunch(target.packageName);
                    return;
                } catch (Exception ignored) { }
            }

            // Fallback caso o aplicativo não esteja instalado/disponível.
            target = findMostUsedMediaApp();
            if (target == null) target = findFirstMediaApp();
            if (target != null) {
                try {
                    Intent launch = new Intent(target.intent);
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    MainActivity.this.startActivity(launch);
                    recordLaunch(target.packageName);
                    return;
                } catch (Exception ignored) { }
            }

            openUrl("https://www.youtube.com/results?search_query=" + Uri.encode(title + " filme"));
        }

        @JavascriptInterface
        public void launchMovieApp() {
            AppTarget target = findZapexCinemaApp();
            if (target == null) target = findMostUsedMediaApp();
            if (target == null) target = findFirstMediaApp();
            if (target != null) {
                try {
                    Intent launch = new Intent(target.intent);
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    MainActivity.this.startActivity(launch);
                    recordLaunch(target.packageName);
                    return;
                } catch (Exception ignored) { }
            }
            toast("Zapéx não encontrado. Instale o aplicativo de Cinema do Smart Hub.");
        }

        @JavascriptInterface
        public void openUsageAccessSettings() {
            try {
                Intent i = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception e) {
                toast("O histórico de uso não está disponível nesta TV");
            }
        }

        @JavascriptInterface
        public String getInstalledAppsJson() {
            List<AppTarget> apps = getLaunchableApps();
            StringBuilder json = new StringBuilder("[");
            for (int i = 0; i < apps.size(); i++) {
                if (i > 0) json.append(',');
                AppTarget a = apps.get(i);
                json.append("{\"label\":\"").append(escape(a.label))
                    .append("\",\"packageName\":\"").append(escape(a.packageName))
                    .append("\",\"icon\":\"").append(escape(iconDataUri(a.packageName))).append("\"}");
            }
            json.append(']');
            return json.toString();
        }

        @JavascriptInterface
        public void openUrl(String url) {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
            } catch (Exception e) {
                toast("Não foi possível abrir o link");
            }
        }

        private AppTarget findFirstApp(String[] candidates) {
            for (String candidate : candidates) {
                AppTarget target = findApp(candidate);
                if (target != null) return target;
            }
            return null;
        }

        @JavascriptInterface
        public void openApplications() {
            runOnUiThread(() -> webView.evaluateJavascript("switchPage('aplicativos')", null));
        }

        @JavascriptInterface
        public void openHomeSettings() {
            try {
                Intent i = new Intent(Settings.ACTION_HOME_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception e) {
                openSystemSettings();
            }
        }

        @JavascriptInterface
        public void openSystemSettings() {
            try {
                Intent i = new Intent(Settings.ACTION_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception e) {
                toast("Configurações do sistema indisponíveis");
            }
        }

        @JavascriptInterface
        public void openNetworkSettings() {
            openSettingsAction(Settings.ACTION_WIFI_SETTINGS, Settings.ACTION_SETTINGS);
        }

        @JavascriptInterface
        public void openBluetoothSettings() {
            openSettingsAction(Settings.ACTION_BLUETOOTH_SETTINGS, Settings.ACTION_SETTINGS);
        }

        @JavascriptInterface
        public void openDisplaySettings() {
            openSettingsAction(Settings.ACTION_DISPLAY_SETTINGS, Settings.ACTION_SETTINGS);
        }

        @JavascriptInterface
        public void openLauncherManager() {
            String[] candidates = {
                    "com.awe.dev.pro.tv",
                    "com.finn.helium",
                    "com.spocky.projengmenu",
                    "com.example.launchermanager"
            };
            for (String pkg : candidates) {
                Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
                if (i != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                    return;
                }
            }

            // Procura pelo aplicativo instalado pelo nome, sem depender de um pacote fixo.
            for (AppTarget app : getLaunchableApps()) {
                String text = normalize(app.label) + normalize(app.packageName);
                if ((text.contains("launchermanager") || (text.contains("launcher") && text.contains("manager")))
                        && !app.packageName.equals(getPackageName())) {
                    try {
                        app.intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(app.intent);
                        return;
                    } catch (Exception ignored) { }
                }
            }

            toast("Launcher Manager não foi encontrado entre os aplicativos instalados");
            openHomeSettings();
        }

        @JavascriptInterface
        public void clearUsageHistory() {
            prefs.edit().clear().apply();
            toast("Histórico de uso limpo");
        }

        @JavascriptInterface
        public void openAppInfo(String label) {
            AppTarget target = findApp(label);
            if (target == null) {
                toast("Aplicativo não encontrado");
                return;
            }
            try {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i.setData(Uri.parse("package:" + target.packageName));
                startActivity(i);
            } catch (Exception e) {
                toast("Não foi possível abrir informações do aplicativo");
            }
        }

        @JavascriptInterface
        public void showAbout() {
            runOnUiThread(() -> webView.evaluateJavascript("showAboutDialog()", null));
        }

        @JavascriptInterface
        public int getLaunchCount(String packageName) {
            return prefs.getInt("launch_" + packageName, 0);
        }

        @JavascriptInterface
        public String getRecentAppsJson() {
            List<AppUsage> list = new ArrayList<>();
            for (String key : prefs.getAll().keySet()) {
                if (!key.startsWith("last_")) continue;
                String pkg = key.substring(5);
                long last = prefs.getLong(key, 0L);
                list.add(new AppUsage(pkg, last));
            }
            Collections.sort(list, (a, b) -> Long.compare(b.last, a.last));
            StringBuilder json = new StringBuilder("[");
            for (int i = 0; i < Math.min(8, list.size()); i++) {
                if (i > 0) json.append(',');
                json.append("{\"packageName\":\"").append(escape(list.get(i).packageName)).append("\"}");
            }
            json.append(']');
            return json.toString();
        }

        @JavascriptInterface
        public void toast(String message) {
            MainActivity.this.toast(message);
        }

        private void openSettingsAction(String preferred, String fallback) {
            try {
                startActivity(new Intent(preferred));
            } catch (Exception e) {
                try {
                    startActivity(new Intent(fallback));
                } catch (Exception ignored) {
                    toast("Configuração indisponível nesta TV");
                }
            }
        }
    }

    private void recordLaunch(String packageName) {
        long now = System.currentTimeMillis();
        int count = prefs.getInt("launch_" + packageName, 0);
        prefs.edit().putInt("launch_" + packageName, count + 1)
                .putLong("last_" + packageName, now).apply();
    }

    private List<AppTarget> getLaunchableApps() {
        Map<String, AppTarget> unique = new HashMap<>();
        android.content.pm.PackageManager pm = getPackageManager();
        Intent leanback = new Intent(Intent.ACTION_MAIN);
        leanback.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        Intent launcher = new Intent(Intent.ACTION_MAIN);
        launcher.addCategory(Intent.CATEGORY_LAUNCHER);

        addResolveInfos(unique, pm.queryIntentActivities(leanback, 0));
        addResolveInfos(unique, pm.queryIntentActivities(launcher, 0));

        List<AppTarget> result = new ArrayList<>();
        for (AppTarget target : unique.values()) {
            if (target.packageName.equals(getPackageName())) continue;
            if (isObviousSystemPackage(target.packageName)) continue;
            result.add(target);
        }
        Collections.sort(result, (a, b) -> a.label.compareToIgnoreCase(b.label));
        return result;
    }

    private void addResolveInfos(Map<String, AppTarget> unique, List<ResolveInfo> infos) {
        for (ResolveInfo ri : infos) {
            if (ri.activityInfo == null) continue;
            String pkg = ri.activityInfo.packageName;
            if (pkg == null || pkg.equals(getPackageName())) continue;
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_LAUNCHER);
            intent.setComponent(new ComponentName(pkg, ri.activityInfo.name));
            String label = String.valueOf(ri.loadLabel(getPackageManager()));
            unique.put(pkg, new AppTarget(label, pkg, intent));
        }
    }

    private boolean isObviousSystemPackage(String pkg) {
        String p = pkg.toLowerCase(Locale.ROOT);
        return p.startsWith("com.android.settings")
                || p.equals("com.android.systemui")
                || p.contains("inputmethod")
                || p.contains("packageinstaller")
                || p.contains("permissioncontroller")
                || p.contains("documentsui");
    }

    private boolean hasUsageAccess() {
        try {
            AppOpsManager appOps = (AppOpsManager) getSystemService(APP_OPS_SERVICE);
            int mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(), getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) {
            return false;
        }
    }

    private Map<String, Long> recentUsage(long days) {
        Map<String, Long> totals = new HashMap<>();
        if (!hasUsageAccess()) return totals;
        try {
            UsageStatsManager usm = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
            long end = System.currentTimeMillis();
            long start = end - days * 24L * 60L * 60L * 1000L;
            List<UsageStats> stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end);
            if (stats != null) {
                for (UsageStats stat : stats) {
                    if (stat.getPackageName() == null) continue;
                    long time = stat.getTotalTimeInForeground();
                    if (time > 0) totals.merge(stat.getPackageName(), time, Long::sum);
                }
            }
        } catch (Exception ignored) { }
        return totals;
    }

    private boolean looksLikeMediaApp(AppTarget target) {
        String text = normalize(target.label) + normalize(target.packageName);
        String[] terms = {
                "netflix", "youtube", "primevideo", "disney", "globoplay", "max", "hbomax",
                "plex", "kodi", "stremio", "tubi", "pluto", "paramount", "stream",
                "player", "video", "filme", "tv", "cinema", "media"
        };
        for (String term : terms) if (text.contains(term)) return true;
        return false;
    }

    private AppTarget findMostUsedMediaApp() {
        List<AppTarget> apps = getLaunchableApps();
        Map<String, Long> usage = recentUsage(21);
        AppTarget best = null;
        long bestTime = 0L;

        // Primeiro: somente aplicativos que parecem ser de vídeo/entretenimento.
        for (AppTarget app : apps) {
            if (!looksLikeMediaApp(app)) continue;
            long time = usage.getOrDefault(app.packageName, 0L);
            if (time > bestTime) {
                bestTime = time;
                best = app;
            }
        }
        if (best != null && bestTime > 0L) return best;

        // Segundo: se a TV não identificar o app como mídia, usa o aplicativo
        // de terceiros mais utilizado nas últimas 3 semanas.
        for (AppTarget app : apps) {
            long time = usage.getOrDefault(app.packageName, 0L);
            if (time > bestTime) {
                bestTime = time;
                best = app;
            }
        }
        return bestTime > 0L ? best : null;
    }

    private AppTarget findFirstMediaApp() {
        List<AppTarget> apps = getLaunchableApps();
        for (AppTarget app : apps) {
            if (looksLikeMediaApp(app)) return app;
        }
        return null;
    }

    private String iconDataUri(String packageName) {
        try {
            Drawable drawable = getPackageManager().getApplicationIcon(packageName);
            Bitmap bitmap;
            if (drawable instanceof BitmapDrawable) {
                bitmap = ((BitmapDrawable) drawable).getBitmap();
            } else {
                int w = Math.max(1, drawable.getIntrinsicWidth());
                int h = Math.max(1, drawable.getIntrinsicHeight());
                bitmap = Bitmap.createBitmap(Math.min(w, 192), Math.min(h, 192), Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(bitmap);
                drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
                drawable.draw(canvas);
            }
            int max = 128;
            if (bitmap.getWidth() > max || bitmap.getHeight() > max) {
                float scale = Math.min((float) max / bitmap.getWidth(), (float) max / bitmap.getHeight());
                bitmap = Bitmap.createScaledBitmap(bitmap, Math.max(1, (int) (bitmap.getWidth() * scale)),
                        Math.max(1, (int) (bitmap.getHeight() * scale)), true);
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }

    private AppTarget findZapexCinemaApp() {
        List<AppTarget> apps = getLaunchableApps();
        AppTarget fallback = null;
        for (AppTarget app : apps) {
            String label = normalize(app.label);
            String pkg = normalize(app.packageName);
            if (label.equals(normalize("Zapéx Acesso premium do Smart Hub Cinema"))) return app;
            if (label.contains("zapex") || pkg.contains("zapex")) {
                if (fallback == null) fallback = app;
                if (label.contains("cinema") || label.contains("smart hub")) return app;
            }
        }
        return fallback;
    }

    private AppTarget findApp(String requested) {
        String wanted = normalize(requested);

        String[] knownPackages = knownPackagesFor(wanted);
        for (String pkg : knownPackages) {
            AppTarget target = targetFromPackage(pkg);
            if (target != null) return target;
        }

        List<android.content.pm.ApplicationInfo> installed = getPackageManager().getInstalledApplications(0);
        for (android.content.pm.ApplicationInfo info : installed) {
            String label = String.valueOf(getPackageManager().getApplicationLabel(info));
            if (matches(wanted, normalize(label), info.packageName.toLowerCase(Locale.ROOT))) {
                Intent i = getPackageManager().getLeanbackLaunchIntentForPackage(info.packageName);
                if (i == null) i = getPackageManager().getLaunchIntentForPackage(info.packageName);
                if (i != null) return new AppTarget(label, info.packageName, i);
            }
        }
        return null;
    }

    private AppTarget targetFromPackage(String pkg) {
        try {
            android.content.pm.PackageManager pm = getPackageManager();
            android.content.pm.ApplicationInfo info = pm.getApplicationInfo(pkg, 0);

            // Android TV normalmente expõe LEANBACK_LAUNCHER; celulares/algumas
            // TVs usam LAUNCHER. Tentamos os dois, sem depender de um único tipo.
            Intent i = pm.getLeanbackLaunchIntentForPackage(pkg);
            if (i == null) i = pm.getLaunchIntentForPackage(pkg);

            if (i == null) {
                Intent query = new Intent(Intent.ACTION_MAIN);
                query.setPackage(pkg);
                query.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
                List<ResolveInfo> leanback = pm.queryIntentActivities(query, 0);
                if (!leanback.isEmpty()) {
                    ResolveInfo ri = leanback.get(0);
                    i = new Intent(Intent.ACTION_MAIN);
                    i.setComponent(new ComponentName(pkg, ri.activityInfo.name));
                }
            }

            if (i == null) {
                Intent query = new Intent(Intent.ACTION_MAIN);
                query.setPackage(pkg);
                query.addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> launcher = pm.queryIntentActivities(query, 0);
                if (!launcher.isEmpty()) {
                    ResolveInfo ri = launcher.get(0);
                    i = new Intent(Intent.ACTION_MAIN);
                    i.setComponent(new ComponentName(pkg, ri.activityInfo.name));
                }
            }

            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                String label = String.valueOf(pm.getApplicationLabel(info));
                return new AppTarget(label, pkg, i);
            }
        } catch (Exception ignored) { }
        return null;
    }

    private boolean startTargetActivity(AppTarget target) {
        if (target == null) return false;
        try {
            Intent launch = new Intent(target.intent);
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            MainActivity.this.startActivity(launch);
            return true;
        } catch (Exception first) {
            // Tenta novamente obtendo a atividade de entrada diretamente pelo pacote.
            try {
                Intent fallback = getPackageManager().getLeanbackLaunchIntentForPackage(target.packageName);
                if (fallback == null) fallback = getPackageManager().getLaunchIntentForPackage(target.packageName);
                if (fallback == null) return false;
                fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                MainActivity.this.startActivity(fallback);
                return true;
            } catch (Exception second) {
                return false;
            }
        }
    }

    private String[] knownPackagesFor(String wanted) {
        if (wanted.equals("netflix")) return new String[]{"com.netflix.ninja", "com.netflix.mediaclient"};
        if (wanted.equals("youtube")) return new String[]{"com.google.android.youtube.tv", "com.google.android.youtube"};
        if (wanted.equals("primevideo")) return new String[]{"com.amazon.amazonvideo.livingroom", "com.amazon.avod.thirdpartyclient"};
        if (wanted.equals("disney")) return new String[]{"com.disney.disneyplus", "com.disney.disneyplus.tv"};
        if (wanted.equals("spotify")) return new String[]{"com.spotify.tv.android"};
        if (wanted.equals("globoplay")) return new String[]{"com.globo.globoplay", "com.globo.globoplay.android"};
        return new String[0];
    }

    private boolean matches(String wanted, String label, String pkg) {
        if (label.equals(wanted) || label.contains(wanted) || wanted.contains(label)) return true;
        if (wanted.equals("netflix")) return pkg.contains("netflix");
        if (wanted.equals("youtube")) return pkg.contains("youtube");
        if (wanted.equals("primevideo")) return pkg.contains("amazonvideo") || pkg.contains("primevideo");
        if (wanted.equals("disney")) return pkg.contains("disney");
        if (wanted.equals("spotify")) return pkg.contains("spotify");
        if (wanted.equals("globoplay")) return pkg.contains("globo") || pkg.contains("globoplay");
        if (wanted.equals("max") || wanted.equals("hbomax")) return pkg.contains("hbo") || pkg.contains("max") || label.contains("max");
        if (wanted.equals("youcine")) return pkg.contains("youcine") || label.contains("youcine");
        if (wanted.equals("zapex")) return pkg.contains("zapex") || label.contains("zapex");
        if (wanted.equals("launchermanager")) return label.contains("launchermanager") || pkg.contains("launcher");
        return false;
    }

    private String normalize(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replace(" ", "").replace("+", "");
    }

    private String escape(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private void toast(String message) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
    }

    private static class AppTarget {
        final String label;
        final String packageName;
        final Intent intent;
        AppTarget(String label, String packageName, Intent intent) {
            this.label = label;
            this.packageName = packageName;
            this.intent = intent;
        }
    }

    private static class AppUsage {
        final String packageName;
        final long last;
        AppUsage(String packageName, long last) {
            this.packageName = packageName;
            this.last = last;
        }
    }
}
