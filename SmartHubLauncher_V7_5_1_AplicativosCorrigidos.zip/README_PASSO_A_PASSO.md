# Smart Hub Launcher V5 — histórico real de uso

Esta versão remove os cards fictícios da tela inicial.

- **Continuar usando**: mostra os aplicativos realmente abertos mais recentemente.
- **Aplicativos em destaque**: ordena os aplicativos por uso e recência.
- O histórico fica salvo localmente no Smart Hub.
- Em Configurações existe a opção **Limpar histórico de uso**.
- A abertura de aplicativos tenta primeiro o launcher de TV, depois o launcher Android normal e por fim a Activity descoberta.

### Limitação importante
Um launcher genérico não consegue saber, sozinho, quais filmes ou episódios foram assistidos dentro de todos os aplicativos de streaming. Cada aplicativo controla seus próprios dados. Por isso esta versão não inventa títulos, porcentagens ou posters. Ela mostra somente dados que o Smart Hub realmente consegue conhecer: os aplicativos que foram abertos e a frequência/recência de uso.

## Como gerar o APK

Use o workflow `.github/workflows/build-apk.yml` pelo GitHub Actions.
