package com.smarthub.launcher;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private WebView webView;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("smarthub", MODE_PRIVATE);
        webView = new WebView(this);
        configureWebView();
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setTextZoom(100);

        webView.setBackgroundColor(0xFF05070B);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new SmartHubBridge(this), "SmartHubAndroid");
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        webView.requestFocus();
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("window.smartHubBack && window.smartHubBack();", null);
        }
    }

    public class SmartHubBridge {
        private final Context context;

        SmartHubBridge(Context context) {
            this.context = context;
        }

        @JavascriptInterface
        public void launchApp(String label) {
            AppTarget target = findApp(label);
            if (target == null) {
                toast("Aplicativo não encontrado: " + label);
                return;
            }
            try {
                Intent launch = new Intent(target.intent);
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                context.startActivity(launch);
                recordLaunch(target.packageName);
            } catch (Exception e) {
                Intent fallback = getPackageManager().getLaunchIntentForPackage(target.packageName);
                if (fallback != null) {
                    try {
                        fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                        context.startActivity(fallback);
                        recordLaunch(target.packageName);
                        return;
                    } catch (Exception ignored) { }
                }
                toast("Não foi possível abrir " + target.label);
            }
        }

        @JavascriptInterface
        public String getInstalledAppsJson() {
            List<AppInfo> apps = collectLaunchableApps();
            JSONArray arr = new JSONArray();
            for (AppInfo app : apps) {
                try {
                    JSONObject o = new JSONObject();
                    o.put("label", app.label);
                    o.put("packageName", app.packageName);
                    o.put("launchCount", prefs.getInt("launch_" + app.packageName, 0));
                    o.put("lastLaunch", prefs.getLong("last_" + app.packageName, 0L));
                    arr.put(o);
                } catch (Exception ignored) { }
            }
            return arr.toString();
        }

        @JavascriptInterface
        public String getRecentAppsJson() {
            List<AppInfo> apps = collectLaunchableApps();
            Collections.sort(apps, (a, b) -> Long.compare(
                    prefs.getLong("last_" + b.packageName, 0L),
                    prefs.getLong("last_" + a.packageName, 0L)));
            JSONArray arr = new JSONArray();
            int added = 0;
            for (AppInfo app : apps) {
                long last = prefs.getLong("last_" + app.packageName, 0L);
                if (last <= 0) continue;
                try {
                    JSONObject o = new JSONObject();
                    o.put("label", app.label);
                    o.put("packageName", app.packageName);
                    o.put("launchCount", prefs.getInt("launch_" + app.packageName, 0));
                    o.put("lastLaunch", last);
                    arr.put(o);
                    if (++added >= 5) break;
                } catch (Exception ignored) { }
            }
            return arr.toString();
        }

        @JavascriptInterface
        public void openApplications() {
            runOnUiThread(() -> webView.evaluateJavascript("switchPage('aplicativos',document.querySelector('[data-page=aplicativos]'))", null));
        }

        @JavascriptInterface
        public void openHomeSettings() {
            try {
                Intent i = new Intent(Settings.ACTION_HOME_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception e) {
                openSystemSettings();
            }
        }

        @JavascriptInterface
        public void openSystemSettings() {
            try {
                Intent i = new Intent(Settings.ACTION_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception e) {
                toast("Configurações do sistema indisponíveis");
            }
        }

        @JavascriptInterface
        public void openNetworkSettings() {
            openSettingsAction(Settings.ACTION_WIFI_SETTINGS, Settings.ACTION_SETTINGS);
        }

        @JavascriptInterface
        public void openBluetoothSettings() {
            openSettingsAction(Settings.ACTION_BLUETOOTH_SETTINGS, Settings.ACTION_SETTINGS);
        }

        @JavascriptInterface
        public void openDisplaySettings() {
            openSettingsAction(Settings.ACTION_DISPLAY_SETTINGS, Settings.ACTION_SETTINGS);
        }

        @JavascriptInterface
        public void openSearch() {
            try {
                Intent i = new Intent(Intent.ACTION_ASSIST);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception e) {
                toast("Pesquisa do sistema indisponível");
            }
        }

        @JavascriptInterface
        public void openNotifications() {
            try {
                Intent i = new Intent("android.settings.NOTIFICATION_SETTINGS");
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception e) {
                openSystemSettings();
            }
        }

        @JavascriptInterface
        public void openLauncherManager() {
            String[] candidates = {
                    "com.awe.dev.pro.tv",
                    "com.finn.helium",
                    "com.spocky.projengmenu",
                    "com.example.launchermanager"
            };
            for (String pkg : candidates) {
                Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
                if (i != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                    return;
                }
            }
            AppTarget byName = findApp("Launcher Manager");
            if (byName != null) {
                try {
                    byName.intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(byName.intent);
                    return;
                } catch (Exception ignored) { }
            }
            openHomeSettings();
        }

        @JavascriptInterface
        public void clearUsageHistory() {
            SharedPreferences.Editor editor = prefs.edit();
            for (String key : new HashSet<>(prefs.getAll().keySet())) {
                if (key.startsWith("launch_") || key.startsWith("last_")) editor.remove(key);
            }
            editor.apply();
            toast("Histórico de uso limpo");
            runOnUiThread(() -> webView.evaluateJavascript("refreshDynamicHome()", null));
        }

        @JavascriptInterface
        public void openAppInfo(String label) {
            AppTarget target = findApp(label);
            if (target == null) {
                toast("Aplicativo não encontrado");
                return;
            }
            try {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i.setData(Uri.parse("package:" + target.packageName));
                startActivity(i);
            } catch (Exception e) {
                toast("Não foi possível abrir informações do aplicativo");
            }
        }

        @JavascriptInterface
        public void showAbout() {
            runOnUiThread(() -> webView.evaluateJavascript("showAboutDialog()", null));
        }

        @JavascriptInterface
        public int getLaunchCount(String packageName) {
            return prefs.getInt("launch_" + packageName, 0);
        }

        @JavascriptInterface
        public void toast(String message) {
            MainActivity.this.toast(message);
        }

        private void openSettingsAction(String preferred, String fallback) {
            try {
                startActivity(new Intent(preferred));
            } catch (Exception e) {
                try {
                    startActivity(new Intent(fallback));
                } catch (Exception ignored) {
                    toast("Configuração indisponível nesta TV");
                }
            }
        }
    }

    private List<AppInfo> collectLaunchableApps() {
        PackageManager pm = getPackageManager();
        Set<String> seen = new HashSet<>();
        List<AppInfo> result = new ArrayList<>();

        Intent leanback = new Intent(Intent.ACTION_MAIN);
        leanback.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        addResolved(pm.queryIntentActivities(leanback, PackageManager.MATCH_ALL), seen, result, pm);

        Intent normal = new Intent(Intent.ACTION_MAIN);
        normal.addCategory(Intent.CATEGORY_LAUNCHER);
        addResolved(pm.queryIntentActivities(normal, PackageManager.MATCH_ALL), seen, result, pm);

        Collections.sort(result, Comparator.comparing(a -> a.label.toLowerCase(Locale.ROOT)));
        return result;
    }

    private void addResolved(List<ResolveInfo> infos, Set<String> seen, List<AppInfo> out, PackageManager pm) {
        for (ResolveInfo ri : infos) {
            if (ri == null || ri.activityInfo == null) continue;
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || seen.contains(pkg)) continue;
            String label = String.valueOf(ri.loadLabel(pm));
            if (label.trim().isEmpty()) label = pkg;
            seen.add(pkg);
            out.add(new AppInfo(label, pkg));
        }
    }

    private void recordLaunch(String packageName) {
        long now = System.currentTimeMillis();
        int count = prefs.getInt("launch_" + packageName, 0);
        prefs.edit().putInt("launch_" + packageName, count + 1)
                .putLong("last_" + packageName, now).apply();
        runOnUiThread(() -> webView.evaluateJavascript("refreshDynamicHome()", null));
    }

    private AppTarget findApp(String requested) {
        String wanted = normalize(requested);
        PackageManager pm = getPackageManager();
        List<AppInfo> installed = collectLaunchableApps();
        for (AppInfo info : installed) {
            if (!matches(wanted, normalize(info.label), info.packageName)) continue;
            Intent i = pm.getLeanbackLaunchIntentForPackage(info.packageName);
            if (i == null) i = pm.getLaunchIntentForPackage(info.packageName);
            if (i != null) return new AppTarget(info.label, info.packageName, i);
        }
        return null;
    }

    private boolean matches(String wanted, String label, String pkg) {
        if (label.equals(wanted) || label.contains(wanted) || wanted.contains(label)) return true;
        if (wanted.equals("netflix")) return pkg.toLowerCase(Locale.ROOT).contains("netflix");
        if (wanted.equals("youtube")) return pkg.toLowerCase(Locale.ROOT).contains("youtube");
        if (wanted.equals("primevideo")) return pkg.toLowerCase(Locale.ROOT).contains("amazonvideo") || pkg.toLowerCase(Locale.ROOT).contains("primevideo");
        if (wanted.equals("disney")) return pkg.toLowerCase(Locale.ROOT).contains("disney");
        if (wanted.equals("spotify")) return pkg.toLowerCase(Locale.ROOT).contains("spotify");
        if (wanted.equals("globoplay")) return pkg.toLowerCase(Locale.ROOT).contains("globo") || pkg.toLowerCase(Locale.ROOT).contains("globoplay");
        if (wanted.equals("max")) return pkg.toLowerCase(Locale.ROOT).contains("hbo") || pkg.toLowerCase(Locale.ROOT).contains("max");
        if (wanted.equals("launchermanager")) return label.contains("launcher manager") || pkg.toLowerCase(Locale.ROOT).contains("launcher");
        return false;
    }

    private String normalize(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replace(" ", "").replace("+", "");
    }

    private void toast(String message) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
    }

    private static class AppInfo {
        final String label;
        final String packageName;
        AppInfo(String label, String packageName) {
            this.label = label;
            this.packageName = packageName;
        }
    }

    private static class AppTarget {
        final String label;
        final String packageName;
        final Intent intent;
        AppTarget(String label, String packageName, Intent intent) {
            this.label = label;
            this.packageName = packageName;
            this.intent = intent;
        }
    }
}
