package com.smarthub.launcher;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    private int purple = Color.rgb(139,92,246);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setBackgroundColor(Color.rgb(7,10,22));

        LinearLayout side = new LinearLayout(this);
        side.setOrientation(LinearLayout.VERTICAL);
        side.setPadding(28,35,18,25);
        side.setGravity(Gravity.TOP);
        side.setBackgroundColor(Color.rgb(10,14,28));
        root.addView(side, new LinearLayout.LayoutParams(210,-1));

        TextView logo = text("SMART\nHUB", 28, Color.WHITE);
        logo.setPadding(8,0,0,35);
        side.addView(logo);

        String[] nav = {"⌂  Início","🎬  Cinema","🏆  Esportes","📱  Conexão","▣  Aplicativos","★  Favoritos","⚙  Configurações"};
        for (String n : nav) {
            TextView item = text(n, 18, Color.WHITE);
            item.setPadding(14,18,8,18);
            item.setFocusable(true);
            item.setOnFocusChangeListener((v, has) -> {
                if(has) v.setBackground(round(purple,18));
                else v.setBackgroundColor(Color.TRANSPARENT);
            });
            side.addView(item);
        }

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(28,25,28,20);
        root.addView(content, new LinearLayout.LayoutParams(0,-1,1));

        TextView title = text("Bem-vindo ao Smart Hub", 30, Color.WHITE);
        content.addView(title);

        TextView hero = text("SEU ENTRETENIMENTO.\nDO SEU JEITO.", 38, Color.WHITE);
        hero.setGravity(Gravity.CENTER_VERTICAL);
        hero.setPadding(28,0,20,0);
        hero.setBackground(round(Color.rgb(25,31,55),28));
        content.addView(hero, new LinearLayout.LayoutParams(-1,190));

        TextView section = text("Continuar assistindo", 22, Color.WHITE);
        section.setPadding(0,22,0,10);
        content.addView(section);

        HorizontalScrollView scroll = new HorizontalScrollView(this);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        String[] cards = {"Filme","Série","Esportes","Cinema"};
        for(String c: cards) {
            TextView card = text(c,20,Color.WHITE);
            card.setGravity(Gravity.CENTER);
            card.setFocusable(true);
            card.setBackground(round(Color.rgb(20,27,48),22));
            row.addView(card, new LinearLayout.LayoutParams(220,105) {{ setMargins(0,0,14,0); }});
        }
        scroll.addView(row);
        content.addView(scroll);

        TextView appsTitle = text("Aplicativos instalados", 22, Color.WHITE);
        appsTitle.setPadding(0,22,0,10);
        content.addView(appsTitle);

        HorizontalScrollView appsScroll = new HorizontalScrollView(this);
        LinearLayout apps = new LinearLayout(this);
        apps.setOrientation(LinearLayout.HORIZONTAL);
        addInstalledApps(apps);
        appsScroll.addView(apps);
        content.addView(appsScroll, new LinearLayout.LayoutParams(-1,125));

        setContentView(root);
    }

    private void addInstalledApps(LinearLayout apps) {
        PackageManager pm = getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        List<android.content.pm.ResolveInfo> list = pm.queryIntentActivities(i, PackageManager.MATCH_ALL);
        if(list.isEmpty()) {
            i.removeCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
            i.addCategory(Intent.CATEGORY_LAUNCHER);
            list = pm.queryIntentActivities(i, PackageManager.MATCH_ALL);
        }
        Collections.sort(list, (a,b) -> a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString()));
        for(android.content.pm.ResolveInfo ri : list) {
            String label = ri.loadLabel(pm).toString();
            TextView app = text(label,17,Color.WHITE);
            app.setGravity(Gravity.CENTER);
            app.setFocusable(true);
            app.setBackground(round(Color.rgb(18,24,43),20));
            app.setCompoundDrawablesWithIntrinsicBounds(null, ri.loadIcon(pm), null, null);
            app.setCompoundDrawablePadding(6);
            app.setOnClickListener(v -> {
                try {
                    Intent launch = pm.getLaunchIntentForPackage(ri.activityInfo.packageName);
                    if(launch != null) startActivity(launch);
                } catch(Exception ignored) {}
            });
            apps.addView(app, new LinearLayout.LayoutParams(150,110) {{ setMargins(0,0,12,0); }});
        }
    }

    private TextView text(String s,int size,int color) {
        TextView v=new TextView(this);
        v.setText(s); v.setTextSize(size); v.setTextColor(color);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    private GradientDrawable round(int color,int radius) {
        GradientDrawable g=new GradientDrawable();
        g.setColor(color); g.setCornerRadius(radius);
        return g;
    }
}
