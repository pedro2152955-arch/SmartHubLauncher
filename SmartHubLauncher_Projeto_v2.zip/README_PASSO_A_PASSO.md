# Smart Hub Launcher v2

Projeto Android nativo — não é site.

Estrutura:
- app/ — aplicativo Android
- .github/workflows/build-apk.yml — workflow de compilação (funciona quando o projeto estiver extraído no repositório)

Para GitHub pelo celular, a forma mais simples é enviar os arquivos extraídos. Se o GitHub não permitir enviar pastas pelo celular, me peça o próximo passo e eu te guio por uma alternativa.
