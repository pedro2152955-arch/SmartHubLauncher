package com.smarthub.launcher;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("smarthub", MODE_PRIVATE);
        webView = new WebView(this);
        configureWebView();
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new SmartHubBridge(this), "SmartHubAndroid");
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        webView.requestFocus();
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("window.smartHubBack && window.smartHubBack();", null);
        }
    }

    public class SmartHubBridge {
        private final Context context;

        SmartHubBridge(Context context) {
            this.context = context;
        }

        @JavascriptInterface
        public void launchApp(String label) {
            AppTarget target = findApp(label);
            if (target == null) {
                toast("Aplicativo não encontrado: " + label);
                return;
            }
            try {
                Intent launch = target.intent;
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(launch);
                recordLaunch(target.packageName);
            } catch (Exception e) {
                toast("Não foi possível abrir " + target.label);
            }
        }

        @JavascriptInterface
        public void openApplications() {
            runOnUiThread(() -> webView.evaluateJavascript("switchPage('aplicativos')", null));
        }

        @JavascriptInterface
        public void openHomeSettings() {
            try {
                Intent i = new Intent(Settings.ACTION_HOME_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception e) {
                openSystemSettings();
            }
        }

        @JavascriptInterface
        public void openSystemSettings() {
            try {
                Intent i = new Intent(Settings.ACTION_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception e) {
                toast("Configurações do sistema indisponíveis");
            }
        }

        @JavascriptInterface
        public void openNetworkSettings() {
            openSettingsAction(Settings.ACTION_WIFI_SETTINGS, Settings.ACTION_SETTINGS);
        }

        @JavascriptInterface
        public void openBluetoothSettings() {
            openSettingsAction(Settings.ACTION_BLUETOOTH_SETTINGS, Settings.ACTION_SETTINGS);
        }

        @JavascriptInterface
        public void openDisplaySettings() {
            openSettingsAction(Settings.ACTION_DISPLAY_SETTINGS, Settings.ACTION_SETTINGS);
        }

        @JavascriptInterface
        public void openLauncherManager() {
            String[] candidates = {
                    "com.awe.dev.pro.tv",
                    "com.finn.helium",
                    "com.spocky.projengmenu",
                    "com.example.launchermanager"
            };
            for (String pkg : candidates) {
                Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
                if (i != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                    return;
                }
            }
            AppTarget byName = findApp("Launcher Manager");
            if (byName != null) {
                byName.intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(byName.intent);
                return;
            }
            openHomeSettings();
        }

        @JavascriptInterface
        public void clearUsageHistory() {
            prefs.edit().clear().apply();
            toast("Histórico de uso limpo");
        }

        @JavascriptInterface
        public void openAppInfo(String label) {
            AppTarget target = findApp(label);
            if (target == null) {
                toast("Aplicativo não encontrado");
                return;
            }
            try {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i.setData(Uri.parse("package:" + target.packageName));
                startActivity(i);
            } catch (Exception e) {
                toast("Não foi possível abrir informações do aplicativo");
            }
        }

        @JavascriptInterface
        public void showAbout() {
            runOnUiThread(() -> webView.evaluateJavascript("showAboutDialog()", null));
        }

        @JavascriptInterface
        public int getLaunchCount(String packageName) {
            return prefs.getInt("launch_" + packageName, 0);
        }

        @JavascriptInterface
        public String getRecentAppsJson() {
            List<AppUsage> list = new ArrayList<>();
            for (String key : prefs.getAll().keySet()) {
                if (!key.startsWith("last_")) continue;
                String pkg = key.substring(5);
                long last = prefs.getLong(key, 0L);
                list.add(new AppUsage(pkg, last));
            }
            Collections.sort(list, (a, b) -> Long.compare(b.last, a.last));
            StringBuilder json = new StringBuilder("[");
            for (int i = 0; i < Math.min(8, list.size()); i++) {
                if (i > 0) json.append(',');
                json.append("{\"packageName\":\"").append(escape(list.get(i).packageName)).append("\"}");
            }
            json.append(']');
            return json.toString();
        }

        @JavascriptInterface
        public void toast(String message) {
            MainActivity.this.toast(message);
        }

        private void openSettingsAction(String preferred, String fallback) {
            try {
                startActivity(new Intent(preferred));
            } catch (Exception e) {
                try {
                    startActivity(new Intent(fallback));
                } catch (Exception ignored) {
                    toast("Configuração indisponível nesta TV");
                }
            }
        }
    }

    private void recordLaunch(String packageName) {
        long now = System.currentTimeMillis();
        int count = prefs.getInt("launch_" + packageName, 0);
        prefs.edit().putInt("launch_" + packageName, count + 1)
                .putLong("last_" + packageName, now).apply();
    }

    private AppTarget findApp(String requested) {
        String wanted = normalize(requested);
        List<android.content.pm.ApplicationInfo> installed = getPackageManager().getInstalledApplications(0);
        for (android.content.pm.ApplicationInfo info : installed) {
            String label = String.valueOf(getPackageManager().getApplicationLabel(info));
            if (matches(wanted, normalize(label), info.packageName)) {
                Intent i = getPackageManager().getLeanbackLaunchIntentForPackage(info.packageName);
                if (i == null) i = getPackageManager().getLaunchIntentForPackage(info.packageName);
                if (i != null) return new AppTarget(label, info.packageName, i);
            }
        }
        return null;
    }

    private boolean matches(String wanted, String label, String pkg) {
        if (label.equals(wanted) || label.contains(wanted) || wanted.contains(label)) return true;
        if (wanted.equals("netflix")) return pkg.contains("netflix");
        if (wanted.equals("youtube")) return pkg.contains("youtube");
        if (wanted.equals("prime video")) return pkg.contains("amazonvideo") || pkg.contains("primevideo");
        if (wanted.equals("disney+")) return pkg.contains("disney");
        if (wanted.equals("spotify")) return pkg.contains("spotify");
        if (wanted.equals("globoplay")) return pkg.contains("globo") || pkg.contains("globoplay");
        if (wanted.equals("max")) return pkg.contains("hbo") || pkg.contains("max");
        if (wanted.equals("launchermanager")) return label.contains("launcher manager") || pkg.contains("launcher");
        return false;
    }

    private String normalize(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replace(" ", "").replace("+", "");
    }

    private String escape(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private void toast(String message) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
    }

    private static class AppTarget {
        final String label;
        final String packageName;
        final Intent intent;
        AppTarget(String label, String packageName, Intent intent) {
            this.label = label;
            this.packageName = packageName;
            this.intent = intent;
        }
    }

    private static class AppUsage {
        final String packageName;
        final long last;
        AppUsage(String packageName, long last) {
            this.packageName = packageName;
            this.last = last;
        }
    }
}
